<!-- Trupi i faqes -->
<?php include "header.php"; ?>
   
        <div class="container tekstifiks">
            <div class="row shtimteksti">
                <div class="col-md-4">
                    <h2>Black box (z-index: 1)</h2>
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown <a class="printerColor" href="#">printer</a> took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
                </div>
                <div class="col-md-4">
                    <h2>Gray box (z-index: 3)</h2> 
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown <a class="printerColor" href="#">printer</a> took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
                </div>
                <div class="col-md-4">
                    <h2>Green box (z-index: 2)</h2>
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown <a class="printerColor" href="#">printer</a> took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 forchildren">
                    <p>Contrary to popular belief, Lorem Ipsum is not simply random text.</p>
                    <p>Contrary to popular belief, Lorem Ipsum is not simply random text.</p>
                    <p>Contrary to popular belief, Lorem Ipsum is not simply random text.</p>
                    <p>Contrary to popular belief, Lorem Ipsum is not simply random text.</p>
                </div>
                <div class="col-md-6">
                    <div class="animation"></div>
                </div>
            </div>
        </div>

        <section id="maincontent">
            <div class="container testimetkomplekse">
                <div class="row">
                    <div class="col-md-2">
                        <button id="mesazhiorar" class="btn btn-sm btn-info" onclick="getHourOftheDay()">Shfaq Mesazhin</button>
                        <button id="ditaktuale" class="btn btn-sm btn-warning" onclick="gjejDiten()">Shfaq Diten</button>
                    </div>
                    <div class="col-md-2">
                        <p id="mesazhifinal"></p>
                        <p id="ditafinale"></p>
                    </div>
                    <div class="col-md-2">
                        <button id="array_one" class="btn btn-sm btn-danger" onclick="shfaqElementet()">Shfaq Mesazhin</button>
                    </div>
                    <div class="col-md-2">
                        <p id="tabelajone"></p>
                    </div>
                    <div class="col-md-2">
                        <p id="whilepargraf"></p>
                    </div>
                    <div class="col-md-2">
                            <label class="form-control">Vendos Numrin</label>
                            <input id="vleraedhene" type="text" class="form-control" />
                            <button onclick="afishoNumrat()" class="btn btn-sm btn-success">Fillo</button>
                    </div>
                    <div class="col-md-2">
                        <input id="nr1" type = "text" />
                        <input id = "nr2" type = "text" />
                        <button onclick="afishoFuqiNumrash()" class="btn btn-sm btn-success">Llogarit</button>
                         <p id="totalprodhim"></p>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <h1 class="text-center">Ckemi</h1>
                    <div class="col-md-5 imazhRrethor"> <!-- paragraf -->
                        <iframe width="460" height="250" 
                        src="https://www.youtube.com/embed/gnlypOSxEkc" 
                        title="YouTube video player" frameborder="0" 
                        allow="accelerometer; autoplay; 
                            clipboard-write; encrypted-media; 
                            gyroscope; picture-in-picture" 
                        allowfullscreen></iframe>  
                    </div>
                    <!-- divider -->
                    <div class="col-md-2 borderi-gri">
                        <table class="table-responsive">
                            <tr><!-- table row -->
                            <th>Company</th> <!-- table header -->
                            <th>Contact</th>
                            <th>Country</th>
                            </tr>
                            <tr>
                            <td>Alfreds Futterkiste</td><!-- table data -->
                            <td>Maria Anders</td>
                            <td>Germany</td>
                            </tr>
                            <tr>
                            <td>Centro comercial Moctezuma</td>
                            <td>Francisco Chang</td>
                            <td>Mexico</td>
                            </tr>
                        </table>
                        <button id="dataora" onclick="shfaqDaten();" class="btn btn-sm btn-success">Shfaq Daten dhe oren</button>
                        <p id="datadheora"></p>
                        <p id="shumajone"></p>
                        <p id="bashkimfjalesh"></p>
                        <button id="mesazhet" onclick="afishoMesazh('Mesazhi yne');">Sheno mesazh</button>
                        <p id="mesazhijone"></p>
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-4">
                        <img class="imazhRrethor" width="460" height="250" alt="im per shtete" src="img/berlin-one.jpg" /> <!-- imazhi -->
                    </div>
                </div>

                <!-- Sektori i sherbimeve -->
                <div class="row ourservices">
                      <h2 class="text-center">Our Services</h2>
                      <p>
                        Lorem Ipsum has been the industry's standard 
                        dummy text ever since the 1500s, when an unknown 
                        printer took a galley of type and scrambled it to 
                        make a type specimen book.
                        <a href="#">Shiko me shume</a>
                      </p>
                      <div class="col-md-2">Web Development</div>
                      <div class="col-md-2">E-commerce</div>
                      <div class="col-md-2">Web Marketing</div>
                      <div class="col-md-2">Seo and Google Ads</div>
                      <div class="col-md-2">Social Media Marketing</div>
                      <div class="col-md-2">Courses</div>  
                </div>

                <div class="row border-gri">  <!-- <===== -->
                    <div class="col-md-5">
                        <video width="460" height="250" controls>
                            <source src="videos/video_trump.mp4" type="video/mp4">
                        </video>
                    </div> 
                    <div class="col-md-2 background-red">
                        <ul>  <!-- un-ordered list -->
                            <li>Buke</li><!-- list item -->
                            <li>Uje</li>
                            <li>Qumesht</li>
                            <li>Veze</li>
                        </ul>
                        <ol>  <!-- ordered list -->
                            <li>Buke</li><!-- list item -->
                            <li>Uje</li>
                            <li>Qumesht</li>
                            <li>Veze</li>
                        </ol>
                        <dl><!-- description list-->
                                <dt>Mengjes</dt> <!-- define tag-->
                                <dd>-- Omlet</dd> <!-- describe tag -->
                        </dl>
                        <div class="elementet-kimike">
                            <ul>
                                <li>
                                H<sub>2</sub>O
                                </li>
                                <li>
                                    CO<sub>2</sub>
                                </li>
                            </ul>
                        </div>
                        <div class="veprim-matematikore">
                            <ul>
                                <li>
                                2<sup>2</sup> = 4
                                </li>
                                <li>
                                    3<sup>2</sup> = 9
                                </li>
                            </ul>
                        </div>
                    </div>  
                    <div class="col-md-5 gri-border">
                      
                        <strong>Lorem Ipsum</strong> has been the industry's standard dummy text ever since the <b>1500s</b>, when an unknown printer took
                        <br/> <!-- breaks to a new line -->
                        a <span>galley</span> of type and scrambled it to make a type specimen book 
                        <hr> <!-- horizontal row-->
                        <p> <!-- pre divide -->
                            Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                        </p>
                        <p>
                            Vizitoni website-in-tone
                            <a href="https://connext.confindustria.it/2021/" title="faqja" alt="faqja">Faqja aktuale</a>
                            <br>
                            Vizitoni faqen tone ne facebook 
                            <a href="https://www.facebook.com/" title="faqja" alt="faqja" target="_blank">Faqe e re</a>
                        </p>
                        
                    </div>
                </div>       
        </div>  <!-- End of container class -->

        </section>

      
        <?php include "footer.php"; ?>