<?php 

include "header.php";

//Si ti kalojme te dhenat ne database
$sql = "INSERT INTO `cars` (Brand, Type, Production_year, Engine, Fuel, KM_done, Price) 
                    VALUES(:brand, :thetype, :theyear, :engine, :fuel, :km, :price)";
$stmt = $conn->prepare($sql);

$stmt ->bindParam(':brand', $_POST['mybrand']);
$stmt ->bindParam(':thetype', $_POST['mytype']);
$stmt ->bindParam(':theyear', $_POST['year']);
$stmt ->bindParam(':engine', $_POST['myengine']);
$stmt ->bindParam(':fuel', $_POST['myfuel']);
$stmt ->bindParam(':km', $_POST['km']);
$stmt ->bindParam(':price', $_POST['theprice']);

$result = $stmt->execute(); 

if($result){
    header("Location: http://localhost/projektiOne/makinat.php");
    exit();
}else{
    echo $result;
}


include "footer.php";

?>


