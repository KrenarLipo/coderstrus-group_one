<!-- Trupi i faqes -->
<?php include "header.php"; ?>
<div class="container">
    <div class="row">
        <!-- Bootstrapi ka 12 kolona -->
        <div class="col-md-1"></div>
        <div class="col-md-1"></div>
        <div class="col-md-1"></div>
        <div class="col-md-1"></div>
        <div class="col-md-1"></div>
        <div class="col-md-1"></div>
        <div class="col-md-1"></div>
        <div class="col-md-1"></div>
        <div class="col-md-1"></div>
        <div class="col-md-1"></div>
        <div class="col-md-1"></div>
        <div class="col-md-1"></div>
        <!-- shuma e kolonave duhet te jete 12 -->
        <div class="col-md-6"></div>   <!-- md = medium screen -->
        <div class="col-md-6"></div>
        <!-- ekranet e medhenj -->
        <div class="col-lg-6"></div> <!-- lg = large screen -->
         <!-- ekranet e vegjel -->
         <div class="col-sm-6"></div> <!-- sm = small screen -->
         <!-- ekranet ekstra te vegjel -->
         <div class="col-xs-6"></div> <!-- xs = extra small screen -->
    </div>
</div>


<?php include "footer.php"; ?>