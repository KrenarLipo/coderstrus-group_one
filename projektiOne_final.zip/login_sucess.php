<?php
session_start();
if(isset($_SESSION["username"])){
    echo '<h3>Mireseerdhe - '.$_SESSION["username"].'</h3>';
    echo '<a href = "logout.php">Logout</a>';
}else{
    header("location: login.php");
}