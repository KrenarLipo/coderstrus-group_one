<?php include "header.php"; ?>

<div class="container">
    <div class="row">
        <div class="col-md-4">
           <?php

             function afishoHelloWorld($value2){
                $var1 = "This is PHP"; //var var1 = "This is PHP"

                echo $var1; //console.log("This is php") 
                echo "<br>";
                echo "Hello World :".$var1."/".$value2."/";  // console.log("this is php" + var1 + "")
             }

             function getPershendetje($extension, $ora2, $ora1){

                if($ora1>$ora2 && $ora1<12){ // 9<8) && 9<12
                  echo "Miremengjes".$extension;
                }elseif($ora1>$ora2 && $ora1<16){  // 13>12 && 13<16
                  echo "Miredreka".$extension;
                }else{
                  echo "Mirembrema".$extension;
                }
             }

            //$val = $_POST['the_number_needed'];
            if(isset($_GET['the_number_needed'])){
              $val =  $_GET['the_number_needed'];
              afishoHelloWorld($val);
            }     
            
            /* === Shfaqja e dates === */
            $t = date("Y-m-d H:i:s");   //h represent hours
            echo "<br> Dita dhe Ora jane ".$t."<br>";

           ?>
        </div>
        <div class="col-md-4">
              <form action = "livesearch.php" method = "get">
                <input type="text" class="form-control" name="the_number_needed">
                <input type="submit" class="btn btn-success" value="Get Value"/>
              </form>
        </div>
        <div class="col-md-3">
          <form method="post">
            <label class="form-control">Orari me i vogel: </label><input class="form-control" type="number" name="orari1">
            <label class="form-control">Orari me i madh: </label><input class="form-control" type="number" name="orari2">
            <button class="btn btn-sm btn-success" type="submit" name="shfaqdaten">Shfaq pershendetjen</button>
          </form>
          <?php
             if(isset($_POST['shfaqdaten'])) {
               $cl = " Klasa";
               $o1 = $_POST['orari1'];
               $o2 = $_POST['orari2'];
               getPershendetje($cl, $o2, $o1);
             }
             
          ?>
        </div>
    </div>
</div>



<?php include "footer.php"; ?>