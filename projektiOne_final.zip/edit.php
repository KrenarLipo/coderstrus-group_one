<?php
    include "header.php";
 
    $output = array('error' => false);
 
    try{
        $id = $_POST['id'];
        $thebrand = $_POST['updatebrand'];
        $thetype = $_POST['updatetype'];
        $theyear = $_POST['update_production_year'];
        $the_engine = $_POST['update_engine'];
        $thefuel = $_POST['update_fuel'];
        $kmm = $_POST['update_km'];
        $theprice = $_POST['update_price'];

        $sql = "UPDATE cars SET Brand = '$thebrand', Type = '$thetype', Production_year = '$theyear', 
                Engine = '$the_engine', Fuel = '$thefuel', KM_done = '$kmm', Price = '$theprice' WHERE id = '$id' ";
        //if-else statement executing query
        if($conn->exec($sql)){
            $output['message'] = 'Member updated successfully';
        } 
        else{
            $output['error'] = true;
            $output['message'] = 'Something went wrong. Cannot update member';
        }
 
    }
    catch(PDOException $e){
        $output['error'] = true;
        $output['message'] = $e->getMessage();
    }
 
    echo json_encode($output);

    include "footer.php"; 

?>