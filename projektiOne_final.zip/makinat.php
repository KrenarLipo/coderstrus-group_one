<?php  include "header.php"; ?>

 <div class="container">
     <div class="row">
       <?php 
         if(isset($_SESSION["username"])){
          echo '<h3>Mireseerdhe - '.$_SESSION["username"].'</h3>';
          echo '<a href = "logout.php">Logout</a>';
          }else{
              header("location: login.php");
          }
       ?>
        <div class="col-md-5 titulli_majtas">
            <h2>Lista e Makinave</h2>
        </div>
        <div class="col-md-5"></div>
        <div class="col-md-2 butoni_djathtas">
            <button type="button" class="btn btn-md btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal">Shto Makina</button>
        </div>
     </div>
 </div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" id="forma_shtimit">
      <div class="modal-body">
        <input class="form-control" type="text" name="brand" id="brand" value="Brand" />
        <input class="form-control" type="text" name="type" id="type" value="Type" />
        <input class="form-control" type="text" name="production_year" id="production_year" value="Production year" />
        <input class="form-control" type="text" name="engine" id="engine" value="Engine" />
        <input class="form-control" type="text" name="fuel" id="fuel" value="Fuel" />
        <input class="form-control" type="text" name="mykm" id="mykm" value="KM" />
        <input class="form-control" type="text" name="price" id="price" value="Price" />
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" id="butsave" class="btn btn-primary">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- update modal -->
<div class="modal" id="edit-cars-modal">
	  	<div class="modal-dialog">
		    <div class="modal-content">
		      	<!-- Modal Header -->
		      	<div class="modal-header">
			        <h4 class="modal-title">Edit Car</h4>
			        <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
		      	</div>
		      	<!-- Modal body -->
		      	<div class="modal-body">
		        	<form action="update.php" id="editForm">
		        		<input class="form-control" type="hidden" class="id" name="id">
				    	<div class="form-group">
						    <label for="email">Brand</label>
						    <input class="form-control updatebrand" type="text" name="updatebrand">
					  	</div>
					  	<div class="form-group">
						    <label for="first_name">Type</label>
						    <input class="form-control updatetype" type="text" name="updatetype">
					  	</div>
					  	<div class="form-group">
						    <label for="last_name">Production year</label>
						    <input class="form-control update_production_year" type="text" name="update_production_year">
					  	</div>
					  	<div class="form-group">
						    <label for="address">Engine</label>
						    <input class="form-control update_engine" type="text" name="update_engine" >
					  	</div>
              <div class="form-group">
						    <label for="address">Fuel</label>
						    <input class="form-control update_fuel" type="text" name="update_fuel">
					  	</div>
              <div class="form-group">
						    <label for="address">How many KM?</label>
						    <input class="form-control update_km" type="text" name="update_km" >
					  	</div>
              <div class="form-group">
						    <label for="address">Price</label>
						    <input class="form-control update_price" type="text" name="update_price" >
					  	</div>
					  	<button type="button" class="btn btn-primary" id="btnUpdateSubmit">Update</button>
					  	<button type="button" class="btn btn-danger float-right" data-bs-dismiss="modal">Close</button>
					</form>
		      	</div>
		    </div>
	  	</div>
</div>
<!-- end update modal -->
<!-- Delete -->
<div class="modal fade" id="delete" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Delete Car</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">  
                <p class="text-center">Are you sure you want to Delete this car?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-bs-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="button" class="btn btn-danger id"><span class="glyphicon glyphicon-trash"></span> Yes</button>
            </div>
 
        </div>
    </div>
</div>

<div class="container">
   <div class="row">
       <div class="col-md-12">
            <?php 
                $stmt = $conn->query("SELECT * FROM cars");
                $result = $stmt->fetchAll();
            ?>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <tr>
                        <th>ID</th>
                        <th>Brand</th>
                        <th>Type</th>
                        <th>Production Year</th>
                        <th>Engine</th>
                        <th>Fuel</th>
                        <th>KM</th>
                        <th>Price</th>
                        <th>Actions</th>
                    </tr>
                    <?php foreach($result as $row){ ?>
                    <tr>
                        <td><?php echo $row['id'];?></td>
                        <td><?php echo $row['Brand'];?></td>
                        <td><?php echo $row['Type'];?></td>
                        <td><?php echo $row['Production_year'];?></td>
                        <td><?php echo $row['Engine'];?></td>
                        <td><?php echo $row['Fuel'];?></td>
                        <td><?php echo $row['KM_done'];?></td>
                        <td><?php echo $row['Price'];?></td>
                        <td>
                            <button class="btn btn-sm btn-success edit" data-id="<?php echo $row['id'];?>">Update</button> 
                            <button class="btn btn-sm btn-danger delete" data-id="<?php echo $row['id'];?>">Delete</button>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
            </div>
           
       </div>
   </div>

</div>



<?php include "footer.php"; ?>