-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2022 at 07:45 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `call_center_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `Adm_Id` int(11) NOT NULL,
  `Username` varchar(250) NOT NULL,
  `Id_role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`Adm_Id`, `Username`, `Id_role`) VALUES
(1, 'Admin_First', 1),
(2, 'Admin_Sec', 1);

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id_blog` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `title` varchar(250) NOT NULL,
  `content` varchar(250) NOT NULL,
  `modified_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `calls`
--

CREATE TABLE `calls` (
  `Id_call` int(11) NOT NULL,
  `date` date NOT NULL,
  `answer` tinyint(1) NOT NULL,
  `operatorId` int(11) NOT NULL,
  `Id_customer` int(11) NOT NULL,
  `Id_status` int(11) NOT NULL,
  `Id_mess` int(11) NOT NULL,
  `updated_status` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `calls`
--

INSERT INTO `calls` (`Id_call`, `date`, `answer`, `operatorId`, `Id_customer`, `Id_status`, `Id_mess`, `updated_status`) VALUES
(1, '2022-01-10', 0, 1, 2, 2, 1, '2022-01-21'),
(2, '2022-01-12', 0, 3, 2, 1, 1, '2022-01-21');

-- --------------------------------------------------------

--
-- Table structure for table `customer1`
--

CREATE TABLE `customer1` (
  `Id_customer` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer1`
--

INSERT INTO `customer1` (`Id_customer`, `email`, `username`) VALUES
(1, 'arta@gmail.com', 'Arta'),
(2, 'blerta@gmail.com', 'Blerta'),
(3, 'tani@gmail.com', 'Tani'),
(4, 'albert@gmail.com', 'Albert');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `Id_job` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `message` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Id_log` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `Id_role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Id_log`, `email`, `username`, `password`, `Id_role`) VALUES
(1, 'admin1@gmail.com', 'Admin_First', '12345678', 1),
(2, 'arta@gmail.com', 'Arta', '123456', 4),
(3, 'donald@gmail.com', 'Donaldi', '12345678', 3),
(4, 'altin@gmail.com', 'Altin', '1234567', 2);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `Id_Man` int(11) NOT NULL,
  `Username` varchar(250) NOT NULL,
  `Adm_Id` int(11) NOT NULL,
  `Id_role` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `updated_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`Id_Man`, `Username`, `Adm_Id`, `Id_role`, `email`, `updated_at`) VALUES
(1, 'Altini', 1, 2, 'altin@gmail.com', '2022-01-21'),
(2, 'Bela', 1, 2, '', '2022-01-21'),
(3, 'Sokoli', 2, 2, '', '2022-01-21'),
(4, 'Arta', 2, 2, '', '2022-01-21');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `Id_mess` int(11) NOT NULL,
  `message` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`Id_mess`, `message`) VALUES
(1, 'Successful call'),
(2, '\r\nFailed call'),
(3, 'Suspicious call'),
(4, 'Did not respond in time');

-- --------------------------------------------------------

--
-- Table structure for table `operatori`
--

CREATE TABLE `operatori` (
  `Id_operator` int(11) NOT NULL,
  `Id_role` int(11) NOT NULL,
  `Id_Man` int(11) NOT NULL,
  `Username` varchar(250) NOT NULL,
  `Id_call` int(11) NOT NULL,
  `Id_Adm` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `updated_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `operatori`
--

INSERT INTO `operatori` (`Id_operator`, `Id_role`, `Id_Man`, `Username`, `Id_call`, `Id_Adm`, `email`, `updated_at`) VALUES
(1, 3, 1, 'Donald', 1, 1, 'donald@gmail.com', '2022-01-21');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `Id_role` int(11) NOT NULL,
  `roletype` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`Id_role`, `roletype`) VALUES
(1, 'Admin'),
(2, 'Manager'),
(3, 'Operator'),
(4, 'Customer');

-- --------------------------------------------------------

--
-- Table structure for table `status_call`
--

CREATE TABLE `status_call` (
  `Id_status` int(11) NOT NULL,
  `status_type` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `status_call`
--

INSERT INTO `status_call` (`Id_status`, `status_type`) VALUES
(1, 'waiting'),
(2, 'done'),
(3, 'in_progress'),
(4, 'Failed');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`Adm_Id`),
  ADD KEY `Id_role` (`Id_role`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id_blog`);

--
-- Indexes for table `calls`
--
ALTER TABLE `calls`
  ADD PRIMARY KEY (`Id_call`),
  ADD KEY `operatorId` (`operatorId`),
  ADD KEY `Id_customer` (`Id_customer`),
  ADD KEY `Id_status` (`Id_status`),
  ADD KEY `Id_mess` (`Id_mess`);

--
-- Indexes for table `customer1`
--
ALTER TABLE `customer1`
  ADD PRIMARY KEY (`Id_customer`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`Id_job`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Id_log`),
  ADD KEY `Id_role` (`Id_role`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`Id_Man`),
  ADD KEY `Id_Adm` (`Adm_Id`),
  ADD KEY `Id_role` (`Id_role`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`Id_mess`);

--
-- Indexes for table `operatori`
--
ALTER TABLE `operatori`
  ADD PRIMARY KEY (`Id_operator`),
  ADD KEY `Id_role` (`Id_role`),
  ADD KEY `Id_Adm` (`Id_Adm`),
  ADD KEY `Id_call` (`Id_call`),
  ADD KEY `Id_Man` (`Id_Man`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`Id_role`);

--
-- Indexes for table `status_call`
--
ALTER TABLE `status_call`
  ADD PRIMARY KEY (`Id_status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator`
--
ALTER TABLE `administrator`
  MODIFY `Adm_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id_blog` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `calls`
--
ALTER TABLE `calls`
  MODIFY `Id_call` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customer1`
--
ALTER TABLE `customer1`
  MODIFY `Id_customer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `Id_job` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `Id_log` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `Id_Man` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `Id_mess` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `operatori`
--
ALTER TABLE `operatori`
  MODIFY `Id_operator` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `Id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `status_call`
--
ALTER TABLE `status_call`
  MODIFY `Id_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `administrator`
--
ALTER TABLE `administrator`
  ADD CONSTRAINT `administrator_ibfk_1` FOREIGN KEY (`Id_role`) REFERENCES `roles` (`Id_role`);

--
-- Constraints for table `calls`
--
ALTER TABLE `calls`
  ADD CONSTRAINT `calls_ibfk_1` FOREIGN KEY (`operatorId`) REFERENCES `operator` (`operatorId`),
  ADD CONSTRAINT `calls_ibfk_2` FOREIGN KEY (`Id_customer`) REFERENCES `customer` (`ID_customer`),
  ADD CONSTRAINT `calls_ibfk_3` FOREIGN KEY (`Id_status`) REFERENCES `status_call` (`Id_status`),
  ADD CONSTRAINT `calls_ibfk_4` FOREIGN KEY (`Id_mess`) REFERENCES `message` (`Id_mess`);

--
-- Constraints for table `login`
--
ALTER TABLE `login`
  ADD CONSTRAINT `login_ibfk_1` FOREIGN KEY (`Id_role`) REFERENCES `roles` (`Id_role`);

--
-- Constraints for table `manager`
--
ALTER TABLE `manager`
  ADD CONSTRAINT `manager_ibfk_1` FOREIGN KEY (`Adm_Id`) REFERENCES `administrator` (`Adm_Id`),
  ADD CONSTRAINT `manager_ibfk_2` FOREIGN KEY (`Id_role`) REFERENCES `roles` (`Id_role`);

--
-- Constraints for table `operatori`
--
ALTER TABLE `operatori`
  ADD CONSTRAINT `operatori_ibfk_1` FOREIGN KEY (`Id_role`) REFERENCES `roles` (`Id_role`),
  ADD CONSTRAINT `operatori_ibfk_2` FOREIGN KEY (`Id_Adm`) REFERENCES `administrator` (`Adm_Id`),
  ADD CONSTRAINT `operatori_ibfk_3` FOREIGN KEY (`Id_call`) REFERENCES `calls` (`Id_call`),
  ADD CONSTRAINT `operatori_ibfk_4` FOREIGN KEY (`Id_Man`) REFERENCES `manager` (`Id_Man`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
