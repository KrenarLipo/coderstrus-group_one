<!DOCTYPE html>
<?php require "db.php"; ?>
<html>

<head>
    <title>Faqja Jone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/mainstyle.css" rel="stylesheet">
</head>

<div class="container">
    <div class="row">
        <nav class="navbar navbar-dark bg-dark">
            <div class="navbar-brand"><img width="150" height="85" src="img/logo.png" class="img-responsive" /></div>
            <ul class="navbar-nav">
                <li class="nav-item active"><a class="nav-link" href="http://localhost/projektiOne/">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Kontakti</a></li>
                <li class="nav-item"><a class="nav-link" href="aboutus.php">Rreth Nesh</a></li>
                <li class="nav-item"><a class="nav-link" href="livesearch.php">Search Page</a></li>
            </ul>
            <form class="form-inline my-2 my-lg-0">
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
            </form>
        </nav>
    </div>
</div>
<body>

<!--ë Ç-->