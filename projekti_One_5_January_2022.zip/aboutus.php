<?php include "header.php"; ?>

<style>
    .tekstikuq {
        color:#0f0!important;
    }
</style>

<div class="container">
    <div class="row">
        <div class="col-md-6">
            <input id="listaime" type="text" name="msg" value="ggg">
            <button id="shfaq-mesazh-2">Shfaq</button>
            <button id="reset-mesazh">Fshi</button>
            <button id="shfaq-liste">Lista Jone</button>
            <p id="afishimliste"></p>
            <p id="shfaqjeliste"></p>
        </div>
        <div class="col-md-6">
            <table class="table table-responsive">
                <tr>
                    <th>Company</th>
                    <th>Contact</th>
                    <th>Country</th>
                </tr>
                <tr>
                    <td>Alfreds Futterkiste</td>
                    <td>Maria Anders</td>
                    <td class="shtetigjerman">Germany</td>
                </tr>
                <tr>
                    <td>Centro comercial Moctezuma</td>
                    <td>Francisco Chang</td>
                    <td>Mexico</td>
                </tr>
            </table> 
        </div>
        <div class="col-md-6">
            <h2 id="perndryshim">Teksti fillestar</h2>
            <button id="ajaxbutton" onclick="merrTekst_teJashtem()">Ndrysho Tekstin e header</button>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>