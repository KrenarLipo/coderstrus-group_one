-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 05, 2022 at 08:26 PM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` int(250) NOT NULL,
  `Brand` varchar(250) NOT NULL,
  `Type` varchar(250) NOT NULL,
  `Production_year` int(5) NOT NULL,
  `Engine` varchar(250) NOT NULL,
  `Fuel` varchar(250) NOT NULL,
  `KM_done` int(250) NOT NULL,
  `Price` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `Brand`, `Type`, `Production_year`, `Engine`, `Fuel`, `KM_done`, `Price`) VALUES
(1, 'Mercedez benz', 'C-klass', 2021, 'Automatic', 'Electric', 0, 60000),
(2, 'BMW', 'x3', 2020, 'Automatic', 'Oil', 0, 70000),
(3, 'Renault', 'Duster', 2019, 'Automatic', 'Diesel', 0, 30000),
(4, 'Mercedez Benz', 'A class', 2015, 'Manuale', 'Oil', 50000, 6000),
(5, 'Toyota', 'Rav 4', 2021, 'Automatic', 'Hybrid', 0, 45000),
(6, 'Toyota', 'Auris', 2008, 'Manual', 'Diesel', 150000, 4700),
(7, 'Volkswagen', 'Passat', 2019, 'Automatic', 'Eletric', 0, 55000);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(250) NOT NULL,
  `roletype` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `roletype`) VALUES
(1, 'Super Admin'),
(2, 'Administrator'),
(3, 'Agent'),
(4, 'Buyer');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `passwordi` varchar(250) NOT NULL,
  `role_id` int(250) NOT NULL,
  `phone_number` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `passwordi`, `role_id`, `phone_number`) VALUES
(1, 'SPA', 'superadmin@email.com', '12345678', 1, NULL),
(2, 'admin', 'admin@email.com', '12345678', 2, 678888999),
(3, 'sellerone', 'sellerone@email.com', '55555555', 3, 667878788);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tessst` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `tessst` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
