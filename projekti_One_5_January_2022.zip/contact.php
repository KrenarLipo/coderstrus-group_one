<?php include "header.php"; ?>

<div class="wrapper">
            <form action="contact.html">
                <label for="fname">Emri</label>
                <input type="text" id="fname" name="firstname" value="Emri">
                <br/> 
                <label for="lname">Mbiemri</label>
                <input type="text" id="lname" name="lastname" value="Mbiemri">
                <br/>
                <label type="text" for="listofcountries">Countries</label>
                <select id="listofcountries">
                    <option value="1">Albania</option>
                    <option value="2">Belgium</option>
                    <option value="3">Canada</option>
                    <option value="4">Deutchland</option>
                    <option value="5">Estonia</option>
                </select>
                <br/>
                <label for="mymessagger">Mesazhi</label>
                <textarea id="mymessagger" rows="5">
                </textarea>
                <input type="submit" value="submit"> 
            </form>
        </div>


<?php include "footer.php"; ?>