console.log("Kemi shkruar javascript");

var variabel;

variabel = "Ky eshte variabli jone";

var nr_one, nr_two, shuma, nr_studentesh;

//ky eshte nje koment
nr_one = 3;
nr_two = 6;
shuma = nr_one + nr_two;
nr_studentesh = 26;

//funksioni per shfaqjen e dates
/* 
    funksione per pjesen e javascriptit ne front-end
    1. onclick => klikim tek
    2. ondblclick => klikim i dyfishte
    3. onmousehover => kur kalojme mousin siper
    4. onmouseleave => kur largojme mousin
    5. etc
*/

/* 
     Math.sqrt => rrenja katrot
     Math.pow => (baza, eksponenti)
     Math.abs => merr vleren absolute
     Math.pi => shfaq numrin PI /3.14444444444
*/
    //-------i=0--i=1--------i = n
var tabela1 = [3, 5, 12, 2, 7, 20];
var gjatesia = tabela1.length;
tabela1.push(9);
gjatesia = tabela1.length;


function shfaqDaten(){
    //var data = document.getElementById('datadheora').innerHTML = Date();
    document.getElementById('shumajone').innerHTML = "shuma eshte: " + Math.pow(shuma, 3);
    document.getElementById('bashkimfjalesh').innerHTML = "Data e sotme eshte: "+Date()+" dhe numri i studenteve perkates: "+nr_studentesh;
}

/* ==== Te krijohet nje funksion qe na merr nje vlere nga html dhe nje vlere nga nje variabel javascript
        edhe na kthen ne fund shumen e vlerave te ngritur ne katror
        ========= */

/* === funksionet komplekse === */
function afishoMesazh(msg){
    //msg = "Mesazhi dy";
    return document.getElementById('mesazhijone').innerHTML = msg;
}

/* === 
Conditions 
 if {
    ///////// something need to happens
 }else{
   ////// otherwise something else happens 
 }

=== */

function getHourOftheDay(){

    let ora = new Date().getHours();
    var mesazhi;

    if(ora <= 11){
        mesazhi = "Miremengjes!";
    }else if(ora > 11 && ora < 17){ // else if(ora > 11 && ora < 17){ mesazhi = "Mirdita!";
        mesazhi = "Mirdita!";
    }else{
        mesazhi = "Mirembrema!";
    }

    console.log(ora);

    document.getElementById('mesazhifinal').innerHTML = mesazhi;

}


/* ==== Switch/case ==== */
function gjejDiten(){
    let day;
    
    switch (new Date().getDay()){
        case 1:
            day = "Monday";
            break;
        case 2:
            day = "Tuesday";
            break;
        case 3:
            day = "Wednesday";
            break;
        case 4:
            day = "Thursday";
            break;
        case 5:
            day = "Friday";
            break;
        case 6:
            day = "Saturday";
        case 7:
            day = "Sunday";
    }

    console.log(new Date().getDay());
    document.getElementById('ditafinale').innerHTML = "Sot eshte "+day;
}

console.log(tabela1);

/* ==== For and While loop ==== */
let array_two = ['hello',4,12,'world', 99];
console.log(array_two);

var ttt = array_two.splice(4,1);
console.log(ttt);

console.log(array_two);

let array_two_modified = array_two.splice(1,2);
array_two_modified = array_two_modified.splice(2,1);

function shfaqElementet() {
    let text = "";
    tabela1.pop();
    gjatesia = tabela1.length;

    for(let i = 0; i<gjatesia; i++){
        text += "Numri eshte: "+tabela1[i]+"<br>";
    }

    document.getElementById('tabelajone').innerHTML = text;
}

var hapaTotale = [1,34,20,35];

for(var i=0; i<hapaTotale.length; i++){
    console.log(hapaTotale[i]);
}

var j=0;
var text = ""; 
var totalhapash = hapaTotale.length;

while(hapaTotale[j] < 35){
   text += " /"+hapaTotale[j];
   j++;
}


function afishoFuqiNumrash(){

    var  Nr1 = parseInt($("#nr1").val());
    var  Nr2 = parseInt($("#nr2").val());
    var  Sum = Nr1 + Nr2;
    
    document.getElementById('totalprodhim').innerHTML = Sum;
}

/* ==== getting values from input fields ==== */
function afishoNumrat(){

        //var Nr1 = $("#nr1").val();
       // var Nr2 = $("#nr2").val();
       // var Sum = Nr1 + Nr2;


    var nr = document.getElementById('vleraedhene').value;
    var tekst = "";
    var i = 0;
    if(nr <=0){
        tekst = "Nuk lejohen vlera negative ose 0";
    }else{
        while(i<nr){
            tekst+="<br>Numri eshte: "+i;
            i++;
        }
    }
    document.getElementById('whilepargraf').innerHTML = tekst;
}

function gjeTotalinShpenzime(tot){
    for(var i=0; i<tot.length; i++){
        var res = tot[i];
    }

    return res;
}

function shfaqListenEBlerjeve(){
    //var lista = $('#listaime').val();

    var ListaBlerjeve = {
        //key =====> value ==========
        product_one:"Ushqime te shportes",
        product_two: "Vere e kuqe",
        product_three: "Gjel Deti",
        product_four: 4
    };

    $('#shfaq-mesazh-2').on('click', function(){
        var lista = $('#listaime').val();
        var shteti = " => "+$('.shtetigjerman').text();
        document.getElementById('afishimliste').innerHTML += lista += shteti;
    });

    $('#shfaq-liste').on('click', function(){
        document.getElementById('afishimliste').innerHTML = ListaBlerjeve.product_one + "/" + ListaBlerjeve.product_three;
    });
}

$('#reset-mesazh').on('click', function(){
    var lista = '';
    document.getElementById('afishimliste').innerHTML = lista;
});

/* ==== Languages ====
    var ourtext = "textAl.txt";

   if($lang == "en") {
      ourtext = "textEng.txt";
   }
===== */

function merrTekst_teJashtem(){

    var ourtext = "ajax_text.txt";

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
        if(this.readyState == 4 && this.status==200){
            document.getElementById('perndryshim').innerHTML = this.responseText;
        }
    };
    xhttp.open("GET",ourtext, true);
    xhttp.send();
}

/* ==== Simple Search module ==== */
function showSearchResults(str){
    if(str.length == 0){
        document.getElementById("livesearch").innerHTML = "";
        document.getElementById("livesearch").style.border="0px";
        return;
    }
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function(){
        if(this.readyState == 4 && this.status==200){
            document.getElementById("livesearch").innerHTML = this.responseText;
            document.getElementById("livesearch").innerHTML = style.border="1px solid #0F0";
        }
    };
    xmlhttp.open("GET","livesearch.php?q="+str, true);
    xmlhttp.send();
}

/* ==== Detyra nr 3 ==== 
Te krijohet nje funksion qe me merr nje vlere nga perdorues, 
kontrollon nese ajo vlera nuk eshte boshe dhe me afishon
te gjithe numrat me te vogel se vlera e dhene dhe na i hedh ne
nje array. 
Funksioni do kthej vleren maksimale te asaj arra-it te krijuar
===== */

/* ==== Document ready jquery ==== */
$( document ).ready(function() {
    shfaqListenEBlerjeve();
});